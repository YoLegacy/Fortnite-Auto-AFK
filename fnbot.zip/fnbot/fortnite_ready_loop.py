#!/usr/bin/env python3
"""
State-aware Fortnite lobby "Ready" loop using template matching.

States:
  WAIT_FOR_READY  -> look for Ready/Play button and click it
                     (also clicks popup buttons like Claim if Play isn't visible)
  WAIT_FOR_POP    -> wait for the button to disappear (queue popped / loading)
  IN_MATCH        -> wait until the Ready button comes back (lobby)
                     (clicks Return to Lobby / Claim etc. along the way)

Failsafe: slam the mouse into any screen corner to kill the script. Ctrl+C also exits cleanly.
Test:     python fortnite_ready_loop.py --test
"""

import argparse
import ctypes
import logging
import os
import sys
import time
from dataclasses import dataclass
from enum import Enum, auto
from typing import List, Optional, Tuple

import cv2
import numpy as np
import pyautogui

# ============================== CONFIG ==============================
# The main button to click to start a match (Play / Ready).
READY_TEMPLATES = [
    "templates/ready.png",
    # "templates/ready_alt.png",
]

# Buttons to click to get past popups and post-match screens.
# Add more any time the script gets stuck on a new screen.
DISMISS_TEMPLATES: List[str] = [
    "templates/return_to_lobby.png",
    "templates/claim.png",
    # "templates/continue.png",
]

MATCH_THRESHOLD = 0.80                         # 0..1; raise if false positives, lower if misses
SCALES = np.linspace(0.8, 1.2, 9)              # multi-scale search for resolution tolerance
SEARCH_REGION: Optional[Tuple[int, int, int, int]] = None
# ^ (left, top, width, height) in screen pixels. Leave as None to search the whole screen.

POLL_LOBBY_SEC = 1.0                           # polling interval in the lobby
POLL_MATCH_SEC = 3.0                           # slower polling while in a match
CONFIRM_HITS = 2                               # consecutive detections required to act
CONFIRM_MISSES = 3                             # consecutive misses to declare "button gone"
CLICK_RETRY_SEC = 20                           # button still visible this long after click -> re-click
MATCH_WARN_MIN = 45                            # warn if a match lasts suspiciously long
START_DELAY_SEC = 5                            # countdown so you can click on Fortnite
LOG_FILE = "fortnite_loop.log"                 # set to None to disable file logging
# ====================================================================

pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.1

log = logging.getLogger("fn-loop")


def setup_logging() -> None:
    fmt = logging.Formatter("%(asctime)s | %(levelname)-7s | %(message)s", "%Y-%m-%d %H:%M:%S")
    log.setLevel(logging.INFO)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    log.addHandler(sh)
    if LOG_FILE:
        fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
        fh.setFormatter(fmt)
        log.addHandler(fh)


def enable_dpi_awareness() -> None:
    """Keep pyautogui coordinates in real pixels on scaled Windows displays."""
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


@dataclass
class Match:
    score: float
    name: str
    cx: float
    cy: float
    box: Tuple[int, int, int, int]


def load_templates(paths: List[str], required: bool) -> List[Tuple[str, np.ndarray]]:
    out = []
    for p in paths:
        if not os.path.isfile(p):
            if required:
                raise FileNotFoundError(f"Template not found: {p}")
            log.warning("Optional template missing, skipping: %s", p)
            continue
        img = cv2.imread(p, cv2.IMREAD_GRAYSCALE)
        if img is None:
            raise ValueError(f"Could not read template image: {p}")
        out.append((p, img))
        log.info("Loaded template %s (%dx%d)", p, img.shape[1], img.shape[0])
    return out


def grab_gray() -> Tuple[np.ndarray, float, Tuple[int, int], object]:
    """Returns (gray frame, pixel ratio vs logical coords, region origin, raw screenshot)."""
    shot = pyautogui.screenshot(region=SEARCH_REGION) if SEARCH_REGION else pyautogui.screenshot()
    gray = cv2.cvtColor(np.array(shot), cv2.COLOR_RGB2GRAY)
    expected_w = SEARCH_REGION[2] if SEARCH_REGION else pyautogui.size().width
    ratio = shot.width / expected_w
    origin = (SEARCH_REGION[0], SEARCH_REGION[1]) if SEARCH_REGION else (0, 0)
    return gray, ratio, origin, shot


def find_best(templates, gray, ratio, origin) -> Optional[Match]:
    best: Optional[Match] = None
    for name, tpl in templates:
        for s in SCALES:
            t = tpl if abs(s - 1.0) < 1e-6 else cv2.resize(
                tpl, None, fx=s, fy=s,
                interpolation=cv2.INTER_AREA if s < 1 else cv2.INTER_CUBIC)
            th, tw = t.shape
            if th > gray.shape[0] or tw > gray.shape[1]:
                continue
            res = cv2.matchTemplate(gray, t, cv2.TM_CCOEFF_NORMED)
            _, score, _, loc = cv2.minMaxLoc(res)
            if np.isnan(score):
                continue
            if best is None or score > best.score:
                best = Match(
                    score=float(score), name=os.path.basename(name),
                    cx=origin[0] + (loc[0] + tw / 2) / ratio,
                    cy=origin[1] + (loc[1] + th / 2) / ratio,
                    box=(loc[0], loc[1], tw, th))
    return best


def detect(templates) -> Optional[Match]:
    gray, ratio, origin, _ = grab_gray()
    m = find_best(templates, gray, ratio, origin)
    return m if (m and m.score >= MATCH_THRESHOLD) else None


def corner_check() -> None:
    """Explicit failsafe check (pyautogui only checks during its own calls)."""
    x, y = pyautogui.position()
    w, h = pyautogui.size()
    if x in (0, w - 1) and y in (0, h - 1):
        raise pyautogui.FailSafeException("Mouse in screen corner")


def click_at(m: Match) -> None:
    pyautogui.moveTo(m.cx, m.cy, duration=0.3)
    time.sleep(0.15)
    pyautogui.click()


def sleep_checked(seconds: float) -> None:
    """Sleep in small slices so the corner failsafe stays responsive."""
    end = time.time() + seconds
    while time.time() < end:
        corner_check()
        time.sleep(min(0.2, max(0.0, end - time.time())))


class State(Enum):
    WAIT_FOR_READY = auto()
    WAIT_FOR_POP = auto()
    IN_MATCH = auto()


def run_loop() -> None:
    ready_tpls = load_templates(READY_TEMPLATES, required=True)
    dismiss_tpls = load_templates(DISMISS_TEMPLATES, required=False)

    state = State.WAIT_FOR_READY
    hits = misses = cycles = 0
    clicked_at = match_started = last_search_log = 0.0

    log.info("Started. Move mouse to any screen corner to abort (Ctrl+C also works).")
    log.info("Switch to Fortnite now... beginning in %d seconds.", START_DELAY_SEC)
    sleep_checked(START_DELAY_SEC)

    while True:
        corner_check()

        if state is State.WAIT_FOR_READY:
            m = detect(ready_tpls)
            hits = hits + 1 if m else 0

            if m and hits >= CONFIRM_HITS:
                click_at(m)
                cycles += 1
                log.info("Ready button detected and clicked (%s, conf %.2f) | cycle #%d",
                         m.name, m.score, cycles)
                clicked_at, hits, misses = time.time(), 0, 0
                state = State.WAIT_FOR_POP
                continue

            # Play button not visible: maybe a popup (Claim, etc.) is blocking the lobby.
            if not m and dismiss_tpls:
                d = detect(dismiss_tpls)
                if d:
                    log.info("Popup button detected (%s, conf %.2f), clicking.", d.name, d.score)
                    click_at(d)
                    hits = 0
                    sleep_checked(1.5)
                    continue

            if not m and time.time() - last_search_log > 30:
                log.info("Searching for Ready button...")
                last_search_log = time.time()
            sleep_checked(POLL_LOBBY_SEC)

        elif state is State.WAIT_FOR_POP:
            m = detect(ready_tpls)
            misses = 0 if m else misses + 1
            if misses >= CONFIRM_MISSES:
                log.info("Button gone -> queue popped / loading. Match in progress...")
                match_started, hits, misses = time.time(), 0, 0
                state = State.IN_MATCH
            elif m and time.time() - clicked_at > CLICK_RETRY_SEC:
                log.warning("Button still visible %ds after click; retrying.", CLICK_RETRY_SEC)
                state = State.WAIT_FOR_READY
            else:
                sleep_checked(POLL_LOBBY_SEC)

        elif state is State.IN_MATCH:
            m = detect(ready_tpls)
            hits = hits + 1 if m else 0
            if hits >= CONFIRM_HITS:
                mins = (time.time() - match_started) / 60
                log.info("Returned to lobby after %.1f min.", mins)
                hits = misses = 0
                state = State.WAIT_FOR_READY
                continue

            # Click Return to Lobby / Claim / etc. if any are on screen
            if dismiss_tpls:
                d = detect(dismiss_tpls)
                if d:
                    log.info("Dismiss button detected (%s, conf %.2f), clicking.", d.name, d.score)
                    click_at(d)
                    sleep_checked(1.5)
                    continue

            if (time.time() - match_started) / 60 > MATCH_WARN_MIN:
                log.warning("Match state has lasted > %d min. Stuck? Check the game.", MATCH_WARN_MIN)
                match_started = time.time()
            sleep_checked(POLL_MATCH_SEC)


def run_test() -> None:
    """Wait a few seconds, take one screenshot, print best score per template, save debug_match.png."""
    tpls = load_templates(READY_TEMPLATES, required=True) + \
           load_templates(DISMISS_TEMPLATES, required=False)
    log.info("TEST MODE: switch to Fortnite now... screenshot in %d seconds.", START_DELAY_SEC)
    sleep_checked(START_DELAY_SEC)

    gray, ratio, origin, shot = grab_gray()
    canvas = cv2.cvtColor(np.array(shot), cv2.COLOR_RGB2BGR)
    for t in tpls:
        m = find_best([t], gray, ratio, origin)
        if m is None:
            log.info("%s: no valid match (template larger than screen?)", t[0])
            continue
        verdict = "PASS" if m.score >= MATCH_THRESHOLD else "below threshold"
        log.info("%s: best score %.3f (%s) at (%.0f, %.0f)", m.name, m.score, verdict, m.cx, m.cy)
        if m.score >= MATCH_THRESHOLD:
            x, y, w, h = m.box
            cv2.rectangle(canvas, (x, y), (x + w, y + h), (0, 255, 0), 3)
    cv2.imwrite("debug_match.png", canvas)
    log.info("Saved debug_match.png (green boxes mark buttons that passed)")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--test", action="store_true", help="single-shot match test + debug image")
    args = ap.parse_args()

    enable_dpi_awareness()
    setup_logging()
    try:
        if args.test:
            run_test()
        else:
            run_loop()
    except KeyboardInterrupt:
        log.info("Ctrl+C received. Shutting down cleanly.")
    except pyautogui.FailSafeException:
        log.warning("FAILSAFE triggered (mouse in corner). Script terminated.")
    except Exception:
        log.exception("Unexpected error")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())