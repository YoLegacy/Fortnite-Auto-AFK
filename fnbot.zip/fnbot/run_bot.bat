@echo off
cd /d "%~dp0"
python fortnite_ready_loop.py
echo.
echo Script stopped.
pause
